#include "hilevel.h"

void hilevel_handler_rst() {
  return;
}

void hilevel_handler_irq() {
  return;
}

void hilevel_handler_svc() {
  return;
}

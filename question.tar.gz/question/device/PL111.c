#include "PL111.h"

volatile PL111_t* LCD = ( volatile PL111_t* )( 0x10020000 );

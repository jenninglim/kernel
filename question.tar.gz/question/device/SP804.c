#include "SP804.h"

volatile SP804_t* TIMER0 = ( volatile SP804_t* )( 0x10011000 );
volatile SP804_t* TIMER1 = ( volatile SP804_t* )( 0x10012000 );
volatile SP804_t* TIMER2 = ( volatile SP804_t* )( 0x10018000 );
volatile SP804_t* TIMER3 = ( volatile SP804_t* )( 0x10019000 );
